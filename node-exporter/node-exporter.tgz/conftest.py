import os
import sys

# Make the package's own hardware_metrics.py importable from tests/.
sys.path.insert(0, os.path.dirname(__file__))
