"""
Jetson hardware metrics — sysfs reader for node-metrics-exporter.

Reads GPU utilization, temperatures, and power straight from sysfs on NVIDIA
Jetson platforms (Orin, Xavier, Nano). Point-in-time ``read_snapshot()`` per
Prometheus scrape — no external services, no NVML, no GPU allocation.

This is the exporter's OWN copy, owned by the op-agent observability side and
deliberately decoupled from the eval-agent's ``hardware_metrics`` (which layers
benchmark-oriented sampling/aggregation on top and evolves independently).
Only the low-level sysfs *discovery* is genuinely shared hardware truth — keep
those path rules in sync across the two when a new Jetson SKU needs a fix.

``read_snapshot()`` is safe for concurrent use.
"""

from __future__ import annotations

import glob
import logging
import os
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, fields
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# =============================================================================
# Sysfs Path Discovery
# =============================================================================

# GPU utilization node (raw 0-1000, divide by 10 for percent). Discovered by
# glob, not hardcoded: the sysfs name embeds the SoC's GPU register base
# (17000000.gpu on Orin/Xavier, other addresses on Nano/TX), and JetPack 6+
# nests platform devices under a `bus@0` container — so neither the address
# nor the depth is stable across SKUs/kernels. We key on the stable `.gpu`
# suffix. Priority: the flat devfreq class first (address- AND nesting-
# agnostic — it's a symlink dir), then the platform node at either depth,
# then the legacy fixed alias. First existing match wins. (Thor exposes no
# load node at all; it falls through to the tegrastats path.)
_GPU_LOAD_GLOBS = [
    "/sys/class/devfreq/*.gpu/device/load",
    "/sys/devices/platform/*.gpu/load",
    "/sys/devices/platform/*/*.gpu/load",
    "/sys/devices/gpu.0/load",
]

# Thermal zone discovery is by `type` (not by hardcoded index): the
# numbering varies across SKUs. Orin's CPU thermal happens to be zone0
# but Jetson Thor exposes zone0=tj-thermal, zone1=gpu-thermal,
# zone2=cpu-thermal — so any hardcoded index pinned to one chip will
# misread on other chips. The discovery scan below picks zones by type
# string, with these well-known names matching every Jetson kernel.
_THERMAL_ZONE_BASE = "/sys/class/thermal"
_CPU_TEMP_TYPE = "cpu-thermal"
_GPU_TEMP_TYPE = "gpu-thermal"
_JUNCTION_TEMP_TYPE = "tj-thermal"

# hwmon base for INA3221 power monitors
_HWMON_BASE = "/sys/class/hwmon"


def _read_sysfs_int(path: str) -> Optional[int]:
    """Read an integer value from a sysfs file.  Returns None on any error.

    Catches a broad Exception class on purpose: some sysfs nodes on
    Jetson Thor (e.g. thermal_zone1/temp = gpu-thermal) `open()` fine
    but throw on read with codec errors that bubble up as TypeError,
    not OSError. A single misbehaving sensor must not be allowed to
    abort the whole snapshot — return None and the caller skips that
    field.
    """
    try:
        with open(path, "r") as f:
            return int(f.read().strip())
    except Exception:  # noqa: BLE001 — intentional, see docstring
        return None


def _read_sysfs_str(path: str) -> Optional[str]:
    """Read a string value from a sysfs file.  Returns None on any error."""
    try:
        with open(path, "r") as f:
            return f.read().strip()
    except Exception:  # noqa: BLE001 — symmetric with _read_sysfs_int
        return None


# One-time discovery results (populated on first call)
_discovered_gpu_path: Optional[str] = None
_discovered_hwmon_path: Optional[str] = None
_discovered_cpu_temp_path: Optional[str] = None
_discovered_gpu_temp_path: Optional[str] = None
_discovered_junction_temp_path: Optional[str] = None
_discovery_done = False
_discovery_lock = threading.Lock()


def _scan_thermal_zone_by_type(target_type: str) -> Optional[str]:
    """Find the first thermal_zone whose `type` file matches `target_type`.

    The /sys/class/thermal/thermal_zone* numbering varies between Jetson
    SKUs (Orin's CPU is zone0, Thor's CPU is zone2), so any code that
    hardcodes an index ends up reading the wrong sensor on the next chip.
    """
    try:
        entries = sorted(os.listdir(_THERMAL_ZONE_BASE))
    except OSError:
        return None
    for entry in entries:
        if not entry.startswith("thermal_zone"):
            continue
        type_path = os.path.join(_THERMAL_ZONE_BASE, entry, "type")
        zone_type = _read_sysfs_str(type_path)
        if zone_type == target_type:
            return os.path.join(_THERMAL_ZONE_BASE, entry, "temp")
    return None


def _scan_hwmon_by_name(target_name: str) -> Optional[str]:
    """Find the first /sys/class/hwmon/hwmonN whose `name` matches.

    Jetson Orin lands INA3221 at hwmon0–hwmon4; Jetson Thor lands it at
    hwmon5 (after pwmfan, pwm_tach, tmp451, soctherm_oc). A fixed-range
    scan misses Thor's monitor entirely. Listing the dir is bound by
    however many hwmon devices the kernel exposes, which is always small.
    """
    try:
        entries = sorted(os.listdir(_HWMON_BASE))
    except OSError:
        return None
    for entry in entries:
        if not entry.startswith("hwmon"):
            continue
        name = _read_sysfs_str(os.path.join(_HWMON_BASE, entry, "name"))
        if name and target_name in name.lower():
            return os.path.join(_HWMON_BASE, entry)
    return None


def _discover_paths() -> None:
    """One-time discovery of sysfs paths available on this platform."""
    global _discovered_gpu_path, _discovered_hwmon_path
    global _discovered_cpu_temp_path, _discovered_gpu_temp_path
    global _discovered_junction_temp_path, _discovery_done

    # GPU load node — discover by glob (SoC address / DT nesting vary).
    for pattern in _GPU_LOAD_GLOBS:
        matches = sorted(glob.glob(pattern))
        if matches:
            _discovered_gpu_path = matches[0]
            break
    if _discovered_gpu_path is None:
        logger.info("Jetson GPU sysfs path not found — GPU utilization unavailable")

    # INA3221 power monitor
    _discovered_hwmon_path = _scan_hwmon_by_name("ina3221")
    if _discovered_hwmon_path is None:
        logger.info("INA3221 hwmon not found — power metrics unavailable")

    # Thermal zones — discover by type, no hardcoded indexes.
    _discovered_cpu_temp_path = _scan_thermal_zone_by_type(_CPU_TEMP_TYPE)
    _discovered_gpu_temp_path = _scan_thermal_zone_by_type(_GPU_TEMP_TYPE)
    _discovered_junction_temp_path = _scan_thermal_zone_by_type(_JUNCTION_TEMP_TYPE)
    for label, path, target in (
        ("CPU", _discovered_cpu_temp_path, _CPU_TEMP_TYPE),
        ("GPU", _discovered_gpu_temp_path, _GPU_TEMP_TYPE),
        ("junction", _discovered_junction_temp_path, _JUNCTION_TEMP_TYPE),
    ):
        if path is None:
            logger.info("%s thermal zone not found (looked for type=%s)", label, target)

    _discovery_done = True


def _ensure_discovered() -> None:
    """Run path discovery exactly once."""
    global _discovery_done
    if not _discovery_done:
        with _discovery_lock:
            if not _discovery_done:
                _discover_paths()


# =============================================================================
# Hardware Snapshot
# =============================================================================

@dataclass(frozen=True)
class JetsonHardwareSnapshot:
    """Single point-in-time hardware reading from Jetson sysfs."""
    gpu_util_pct: Optional[float] = None
    cpu_temp_c: Optional[float] = None
    gpu_temp_c: Optional[float] = None
    junction_temp_c: Optional[float] = None
    vdd_gpu_soc_w: Optional[float] = None
    vdd_cpu_cv_w: Optional[float] = None
    vin_sys_5v0_w: Optional[float] = None
    total_power_w: Optional[float] = None
    timestamp: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {f.name: getattr(self, f.name) for f in fields(self)}


def _read_power_rail(hwmon_path: str, channel: int) -> Optional[float]:
    """Read power from an INA3221 channel (voltage × current / 1e6 = watts)."""
    curr = _read_sysfs_int(os.path.join(hwmon_path, f"curr{channel}_input"))
    volt = _read_sysfs_int(os.path.join(hwmon_path, f"in{channel}_input"))
    if curr is not None and volt is not None:
        return round((curr * volt) / 1_000_000, 4)
    return None


def _read_tegrastats_gpu_util(timeout_s: float = 2.0) -> Optional[float]:
    """Run `tegrastats` for one sample and parse the GR3D_FREQ field.

    Fallback for SoCs (Jetson Thor and later) that don't expose GPU load
    via the sysfs load node. `tegrastats` line format contains
    `GR3D_FREQ X%@Y`, where X is the 3D-engine busy percentage.

    Requires the host's tegrastats binary on PATH — the op-agent chart only
    bind-mounts it when observability.gpu.jetsonUseTegrastats=true (it is
    absent on EVE-virtualized Jetson). When unavailable this returns None.
    """
    if not shutil.which("tegrastats"):
        return None
    proc = None
    try:
        # 100 ms interval — first line lands quickly; we kill immediately
        # after parsing a single sample so this doesn't run continuously.
        proc = subprocess.Popen(
            ["tegrastats", "--interval", "100"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            line = proc.stdout.readline() if proc.stdout else ""
            if not line:
                break
            m = re.search(r"GR3D_FREQ\s+(\d+)%", line)
            if m:
                return float(m.group(1))
    except Exception:  # noqa: BLE001 — best-effort scrape
        logger.debug("tegrastats invocation failed", exc_info=True)
        return None
    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                proc.kill()
    return None


def read_snapshot() -> JetsonHardwareSnapshot:
    """
    Take a single hardware metrics reading from sysfs.

    Returns a snapshot with ``None`` for any unavailable metric.
    """
    _ensure_discovered()

    # GPU utilization. Orin/Xavier/Nano expose this via sysfs (raw 0-1000 → /10
    # for percent). Jetson Thor removed those nodes — the only source there is
    # tegrastats. We try sysfs first (cheap file read) and only fork tegrastats
    # if sysfs isn't available, so Orin/Xavier scrapes stay fast.
    gpu_util = None
    if _discovered_gpu_path:
        raw = _read_sysfs_int(_discovered_gpu_path)
        if raw is not None:
            gpu_util = round(raw / 10.0, 1)
    if gpu_util is None:
        gpu_util = _read_tegrastats_gpu_util()

    # Temperatures — read from the discovered-by-type paths, not hardcoded indexes.
    def _read_temp(path: Optional[str]) -> Optional[float]:
        if path is None:
            return None
        raw = _read_sysfs_int(path)
        return None if raw is None else round(raw / 1000.0, 1)

    cpu_temp = _read_temp(_discovered_cpu_temp_path)
    gpu_temp = _read_temp(_discovered_gpu_temp_path)
    junction_temp = _read_temp(_discovered_junction_temp_path)

    # Power rails
    vdd_gpu_soc = None
    vdd_cpu_cv = None
    vin_sys_5v0 = None
    total_power = None
    if _discovered_hwmon_path:
        vdd_gpu_soc = _read_power_rail(_discovered_hwmon_path, 1)
        vdd_cpu_cv = _read_power_rail(_discovered_hwmon_path, 2)
        vin_sys_5v0 = _read_power_rail(_discovered_hwmon_path, 3)
        parts = [p for p in (vdd_gpu_soc, vdd_cpu_cv, vin_sys_5v0) if p is not None]
        if parts:
            total_power = round(sum(parts), 4)

    return JetsonHardwareSnapshot(
        gpu_util_pct=gpu_util,
        cpu_temp_c=cpu_temp,
        gpu_temp_c=gpu_temp,
        junction_temp_c=junction_temp,
        vdd_gpu_soc_w=vdd_gpu_soc,
        vdd_cpu_cv_w=vdd_cpu_cv,
        vin_sys_5v0_w=vin_sys_5v0,
        total_power_w=total_power,
        timestamp=time.time(),
    )
