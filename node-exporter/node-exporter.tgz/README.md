# node-metrics-exporter

Prometheus exporter for Jetson hardware metrics. Wraps
[`ondevice-eval-agent/webapp/eval/hardware_metrics.py`](../ondevice-eval-agent/webapp/eval/hardware_metrics.py)
as a library — that file is intentionally unmodified.

Used as the **fallback** Jetson GPU/temp/power exporter when
DCGM-exporter doesn't fully cover a Jetson SKU. The op-agent chart picks
this DaemonSet (gated on `observability.gpu.jetsonProvider=custom`).

## Build

The Docker build context **must be the repo root** so the Dockerfile can
pull in `ondevice-eval-agent/webapp/eval/hardware_metrics.py`:

```sh
make image
make push
```

## Phase 1 TODO

- The library's read function name varies (`get_metrics` / `collect` /
  `snapshot` / …). `app.py` probes those names; once the canonical name is
  confirmed, hard-pin it.
