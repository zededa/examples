"""Tests for node-metrics-exporter's Jetson sysfs reader.

This reader is a decoupled copy of the eval-agent's, so the tests pin the
SKU/kernel-agnostic GPU-load discovery: the JetPack-6 support must not
silently regress (that's the drift risk of keeping a separate copy).
"""
import hardware_metrics as hw


def _reset_discovery():
    hw._discovery_done = False
    hw._discovered_gpu_path = None
    hw._discovered_hwmon_path = None
    hw._discovered_cpu_temp_path = None
    hw._discovered_gpu_temp_path = None
    hw._discovered_junction_temp_path = None


def test_gpu_load_globs_cover_known_layouts():
    globs = hw._GPU_LOAD_GLOBS
    assert "/sys/class/devfreq/*.gpu/device/load" in globs       # flat, preferred
    assert "/sys/devices/platform/*.gpu/load" in globs           # pre-JP6 depth
    assert "/sys/devices/platform/*/*.gpu/load" in globs         # JP6 bus@0 depth
    # keyed on the stable `.gpu` suffix, never a fixed SoC address
    assert all(".gpu/" in p for p in globs if not p.endswith("gpu.0/load"))


def test_discovers_gpu_by_suffix_not_sibling_engines(tmp_path, monkeypatch):
    devfreq = tmp_path / "sys/class/devfreq"
    (devfreq / "15480000.nvdec/device").mkdir(parents=True)
    (devfreq / "15480000.nvdec/device/load").write_text("999\n")  # sibling engine
    (devfreq / "17000000.gpu/device").mkdir(parents=True)
    (devfreq / "17000000.gpu/device/load").write_text("500\n")    # the GPU
    monkeypatch.setattr(hw, "_GPU_LOAD_GLOBS", [str(devfreq / "*.gpu/device/load")])
    _reset_discovery()
    assert hw.read_snapshot().gpu_util_pct == 50.0  # 500/10 — from the .gpu node


def test_read_snapshot_never_raises():
    _reset_discovery()
    snap = hw.read_snapshot()
    assert isinstance(snap, hw.JetsonHardwareSnapshot)
    assert {"gpu_util_pct", "gpu_temp_c", "total_power_w"} <= set(snap.to_dict())
