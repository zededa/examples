"""
node-metrics-exporter: Prometheus exporter for Jetson hardware metrics.

Reads Jetson hardware via this package's own `hardware_metrics.py` and
exposes the readings under the metric names the op-agent chart's Grafana
dashboards query for.

Mapping (snapshot field → exposed metric):
    gpu_util_pct      → jetson_gpu_util_pct
    cpu_temp_c        → jetson_cpu_temp_c
    junction_temp_c   → jetson_junction_temp_c
    vdd_gpu_soc_w     → jetson_power_watts{rail="vdd_gpu_soc"}
    vdd_cpu_cv_w      → jetson_power_watts{rail="vdd_cpu_cv"}
    vin_sys_5v0_w     → jetson_power_watts{rail="vin_sys_5v0"}
    total_power_w     → jetson_power_watts{rail="total"}

Memory metrics (`jetson_memory_used_bytes` / `jetson_memory_total_bytes`)
were dropped — `hardware_metrics.read_snapshot()` doesn't sample memory,
and node-exporter already exposes the same data via
`node_memory_MemTotal_bytes` / `node_memory_MemAvailable_bytes`.

Any sysfs read returning None (sensor missing on this Jetson SKU) is
omitted from the scrape — Prometheus treats absent series as no-data,
which is the right semantic for the dashboard.
"""
from __future__ import annotations

import logging
import os
import sys

from flask import Flask, Response
from prometheus_client import CollectorRegistry, Gauge, generate_latest, CONTENT_TYPE_LATEST

# hardware_metrics.py is co-located in this package (COPYed to /app by the
# Dockerfile). Add /app to sys.path so it imports whether launched as a module
# or by gunicorn from /app.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import hardware_metrics  # type: ignore
except ImportError:  # pragma: no cover — surfaces only if the file is missing
    hardware_metrics = None  # type: ignore

logger = logging.getLogger("node-metrics-exporter")
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))

app = Flask(__name__)


# Snapshot field → (metric_name, description). Skipped if value is None
# at scrape time, so a non-Jetson host or a SKU that doesn't expose a
# given sysfs node returns no series for that metric (rather than 0,
# which would be wrong).
SCALAR_METRICS = (
    ("gpu_util_pct",     "jetson_gpu_util_pct",     "Jetson GPU utilization (%)"),
    ("cpu_temp_c",       "jetson_cpu_temp_c",       "Jetson CPU temperature (°C)"),
    ("gpu_temp_c",       "jetson_gpu_temp_c",       "Jetson GPU temperature (°C)"),
    ("junction_temp_c",  "jetson_junction_temp_c",  "Jetson junction temperature (°C)"),
)

# Snapshot field → (rail label) for jetson_power_watts{rail=...}.
POWER_RAILS = (
    ("vdd_gpu_soc_w", "vdd_gpu_soc"),
    ("vdd_cpu_cv_w",  "vdd_cpu_cv"),
    ("vin_sys_5v0_w", "vin_sys_5v0"),
    ("total_power_w", "total"),
)


def _read_snapshot_dict() -> dict:
    """Take a snapshot via hardware_metrics.read_snapshot() and flatten to a dict."""
    if hardware_metrics is None:
        logger.error("hardware_metrics module not importable; emitting empty scrape")
        return {}
    try:
        snap = hardware_metrics.read_snapshot()
    except Exception:  # noqa: BLE001 — best-effort scrape
        logger.exception("hardware_metrics.read_snapshot() failed")
        return {}
    # JetsonHardwareSnapshot has a to_dict() helper; if a future revision
    # changes the API we still try to coerce sensibly.
    if hasattr(snap, "to_dict"):
        return snap.to_dict()
    if isinstance(snap, dict):
        return snap
    logger.warning(
        "read_snapshot() returned %s; expected JetsonHardwareSnapshot or dict",
        type(snap).__name__,
    )
    return {}


@app.route("/metrics")
def metrics() -> Response:
    snap = _read_snapshot_dict()
    reg = CollectorRegistry()

    for src, name, desc in SCALAR_METRICS:
        val = snap.get(src)
        if val is None:
            continue
        try:
            Gauge(name, desc, registry=reg).set(float(val))
        except (TypeError, ValueError):
            logger.warning("could not coerce %s=%r to float", src, val)

    rail_gauge = Gauge(
        "jetson_power_watts",
        "Jetson power draw (W) per rail; rail='total' is the sum of available rails",
        ["rail"],
        registry=reg,
    )
    emitted_any_rail = False
    for src, rail in POWER_RAILS:
        val = snap.get(src)
        if val is None:
            continue
        try:
            rail_gauge.labels(rail=rail).set(float(val))
            emitted_any_rail = True
        except (TypeError, ValueError):
            logger.warning("could not coerce %s=%r to float", src, val)
    if not emitted_any_rail:
        # Avoid an orphan metric family with zero series in the output.
        reg.unregister(rail_gauge)

    return Response(generate_latest(reg), mimetype=CONTENT_TYPE_LATEST)


@app.route("/healthz")
def healthz() -> Response:
    return Response("ok\n", mimetype="text/plain")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "9100")))
